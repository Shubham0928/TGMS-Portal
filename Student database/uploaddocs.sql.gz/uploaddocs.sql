-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 09, 2022 at 05:27 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `studentinfo`
--

-- --------------------------------------------------------

--
-- Table structure for table `uploaddocs`
--

CREATE TABLE `uploaddocs` (
  `id` int(255) NOT NULL,
  `std_id` int(255) NOT NULL,
  `C_title` varchar(255) NOT NULL,
  `C_des` varchar(255) NOT NULL,
  `file_name` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `uploaddocs`
--

INSERT INTO `uploaddocs` (`id`, `std_id`, `C_title`, `C_des`, `file_name`) VALUES
(1, 1, 'CN', 'lerarning DSA', 'Student_Uploads/CNS module 1 .pdf'),
(3, 1, ' TCS', 'Internship On Data anayalst', 'Student_Uploads/antiragging_form.pdf');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `uploaddocs`
--
ALTER TABLE `uploaddocs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `std_id` (`std_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `uploaddocs`
--
ALTER TABLE `uploaddocs`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `uploaddocs`
--
ALTER TABLE `uploaddocs`
  ADD CONSTRAINT `uploaddocs_ibfk_1` FOREIGN KEY (`std_id`) REFERENCES `signinfo` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
