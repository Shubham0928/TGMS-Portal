-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 09, 2022 at 05:26 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `studentinfo`
--

-- --------------------------------------------------------

--
-- Table structure for table `signinfo`
--

CREATE TABLE `signinfo` (
  `id` int(11) NOT NULL,
  `Sname` varchar(255) NOT NULL,
  `SAddNo` varchar(255) NOT NULL,
  `SUname` varchar(255) NOT NULL,
  `Semail` varchar(255) NOT NULL,
  `Spassword` varchar(255) NOT NULL,
  `FatherName` varchar(255) NOT NULL,
  `FatherEmail` varchar(255) NOT NULL,
  `FatherPhone` varchar(255) NOT NULL,
  `MotherName` varchar(255) NOT NULL,
  `MotherEmail` varchar(255) NOT NULL,
  `MotherPhone` varchar(255) NOT NULL,
  `Academicyear` date NOT NULL,
  `Saddress` varchar(1000) NOT NULL,
  `Simage` varchar(1000) NOT NULL,
  `sscboard` varchar(255) NOT NULL,
  `sscmarks` varchar(255) NOT NULL,
  `sscyear` year(4) NOT NULL,
  `hscborad` varchar(255) NOT NULL,
  `hscmarks` varchar(255) NOT NULL,
  `hscyear` year(4) NOT NULL,
  `fe` varchar(255) NOT NULL,
  `femarks` varchar(255) NOT NULL,
  `feyear` year(4) NOT NULL,
  `se` varchar(255) NOT NULL,
  `semarks` varchar(255) NOT NULL,
  `seyear` year(4) NOT NULL,
  `te` varchar(255) NOT NULL,
  `temarks` varchar(255) NOT NULL,
  `teyear` year(4) NOT NULL,
  `be` varchar(255) NOT NULL,
  `bemarks` varchar(255) NOT NULL,
  `beyear` year(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `signinfo`
--

INSERT INTO `signinfo` (`id`, `Sname`, `SAddNo`, `SUname`, `Semail`, `Spassword`, `FatherName`, `FatherEmail`, `FatherPhone`, `MotherName`, `MotherEmail`, `MotherPhone`, `Academicyear`, `Saddress`, `Simage`, `sscboard`, `sscmarks`, `sscyear`, `hscborad`, `hscmarks`, `hscyear`, `fe`, `femarks`, `feyear`, `se`, `semarks`, `seyear`, `te`, `temarks`, `teyear`, `be`, `bemarks`, `beyear`) VALUES
(1, 'Rahul', '2020HE0340', 'RahulReddy', 'rahulkumarsr20it@student.mes.ac.in', 'e10adc3949ba59abbe56e057f20f883e', 'Shrinivas Reddy', 'shrinivas@gmail.com', '1234567890', 'Samudra S reddy', 'samudra@gmail.com', '1234567890', '2022-11-04', 'At-rees near icicibank', 'Student Image/rahul.jpg', 'ssc', '100', 2018, 'HSC', '100', 2020, 'MU ', '10', 2021, 'MU', '10', 2022, '', '', 0000, '', '  ', 0000),
(8, 'Rohit', '2020HE0341', 'Rohit', 'rahul1114@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'Shrinivas R Reddy', 'ss123@gmail.com', '09960971996', 'Samudra S reddy', '2563@gmail.com', '09960971996', '2022-11-08', 'At-rees near icicibank', 'Student Image/IMG_20210111_204156.jpg', '', '', 0000, '', '', 0000, ' ', '', 0000, '', '', 0000, '', '', 0000, '', '  ', 0000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `signinfo`
--
ALTER TABLE `signinfo`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `signinfo`
--
ALTER TABLE `signinfo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
