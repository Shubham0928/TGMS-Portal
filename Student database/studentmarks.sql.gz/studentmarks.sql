-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 09, 2022 at 05:27 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `studentinfo`
--

-- --------------------------------------------------------

--
-- Table structure for table `studentmarks`
--

CREATE TABLE `studentmarks` (
  `id` int(255) NOT NULL,
  `Student_id` int(255) NOT NULL,
  `IP1` int(255) NOT NULL,
  `IP2` int(255) NOT NULL,
  `IPT` int(255) NOT NULL,
  `SE1` int(255) NOT NULL,
  `SE2` int(255) NOT NULL,
  `SETA` int(255) NOT NULL,
  `ADMT1` int(255) NOT NULL,
  `ADMT2` int(255) NOT NULL,
  `ADMTT` int(255) NOT NULL,
  `CNS1` int(255) NOT NULL,
  `CNS2` int(255) NOT NULL,
  `CNST` int(255) NOT NULL,
  `EEB1` int(255) NOT NULL,
  `EEB2` int(255) NOT NULL,
  `EEBT` int(255) NOT NULL,
  `TOTAL1` int(255) NOT NULL,
  `TOTAL2` int(255) NOT NULL,
  `Average` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `studentmarks`
--

INSERT INTO `studentmarks` (`id`, `Student_id`, `IP1`, `IP2`, `IPT`, `SE1`, `SE2`, `SETA`, `ADMT1`, `ADMT2`, `ADMTT`, `CNS1`, `CNS2`, `CNST`, `EEB1`, `EEB2`, `EEBT`, `TOTAL1`, `TOTAL2`, `Average`) VALUES
(1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 2, 1, 1, 2, 1, 1, 2, 5, 5, 5);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `studentmarks`
--
ALTER TABLE `studentmarks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Student_id` (`Student_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `studentmarks`
--
ALTER TABLE `studentmarks`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `studentmarks`
--
ALTER TABLE `studentmarks`
  ADD CONSTRAINT `studentmarks_ibfk_1` FOREIGN KEY (`Student_id`) REFERENCES `signinfo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
