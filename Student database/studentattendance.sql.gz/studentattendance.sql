-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 09, 2022 at 05:27 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `studentinfo`
--

-- --------------------------------------------------------

--
-- Table structure for table `studentattendance`
--

CREATE TABLE `studentattendance` (
  `id` int(255) NOT NULL,
  `Student_id` int(11) NOT NULL,
  `IPT` int(255) NOT NULL,
  `IPA` int(255) NOT NULL,
  `SETA` int(255) NOT NULL,
  `SEA` int(255) NOT NULL,
  `ADMTT` int(255) NOT NULL,
  `ADMTA` int(255) NOT NULL,
  `CNST` int(255) NOT NULL,
  `CNSA` int(255) NOT NULL,
  `EEBT` int(255) NOT NULL,
  `EEBA` int(255) NOT NULL,
  `Total_C` int(255) NOT NULL,
  `Total_A` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `studentattendance`
--

INSERT INTO `studentattendance` (`id`, `Student_id`, `IPT`, `IPA`, `SETA`, `SEA`, `ADMTT`, `ADMTA`, `CNST`, `CNSA`, `EEBT`, `EEBA`, `Total_C`, `Total_A`) VALUES
(2, 8, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 15, 15),
(4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 5, 5);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `studentattendance`
--
ALTER TABLE `studentattendance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Student_id` (`Student_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `studentattendance`
--
ALTER TABLE `studentattendance`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `studentattendance`
--
ALTER TABLE `studentattendance`
  ADD CONSTRAINT `studentattendance_ibfk_1` FOREIGN KEY (`Student_id`) REFERENCES `signinfo` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
