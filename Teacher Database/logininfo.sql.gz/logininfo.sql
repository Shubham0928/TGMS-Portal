-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 11, 2022 at 05:12 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `teacherlogin`
--

-- --------------------------------------------------------

--
-- Table structure for table `logininfo`
--

CREATE TABLE `logininfo` (
  `sr` int(11) NOT NULL,
  `UserName` varchar(255) NOT NULL,
  `teacher_name` varchar(255) NOT NULL,
  `subject_name` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `profile_p` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `logininfo`
--

INSERT INTO `logininfo` (`sr`, `UserName`, `teacher_name`, `subject_name`, `Password`, `profile_p`) VALUES
(1, 'Prachi S', 'Prachi Sorte', 'Internet Programing', 'e10adc3949ba59abbe56e057f20f883e', 'Teacher Profile/Ms.-Prachi-Sorte.jpg'),
(2, 'Kajal P', 'Kajal Patel', 'Software engineering', 'e10adc3949ba59abbe56e057f20f883e', 'Teacher Profile/Ms.-Kajal-Patel.jpg'),
(3, 'Rupali S', 'Rupali Sathe', 'Computer Network And Security', 'e10adc3949ba59abbe56e057f20f883e', 'Teacher Profile/ms-rupali-mangesh-sathe.jpg'),
(4, 'Poonam P', 'Poonam Phatak', 'Entrepreneurship & Entrepreneurial Business', 'e10adc3949ba59abbe56e057f20f883e', 'Teacher Profile/Ms.-Poonam-Pathak.jpg'),
(5, 'Siddhesh K', 'Siddhesh Khanvilkar', 'Advance Database Management System', 'e10adc3949ba59abbe56e057f20f883e', 'Teacher Profile/Mr.-Siddhesh-Khanvilkar.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `logininfo`
--
ALTER TABLE `logininfo`
  ADD PRIMARY KEY (`sr`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `logininfo`
--
ALTER TABLE `logininfo`
  MODIFY `sr` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
